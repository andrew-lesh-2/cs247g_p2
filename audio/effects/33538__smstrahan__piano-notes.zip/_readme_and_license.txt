Pack downloaded from Freesound
----------------------------------------

"Piano Notes"

This Pack of sounds contains sounds by the following user:
 - smstrahan ( https://freesound.org/people/smstrahan/ )

You can find this pack online at: https://freesound.org/people/smstrahan/packs/33538/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 608992__smstrahan__gsharp.mp3.mp3
    * url: https://freesound.org/s/608992/
    * license: Creative Commons 0
  * 608991__smstrahan__asharp.mp3.mp3
    * url: https://freesound.org/s/608991/
    * license: Creative Commons 0
  * 608990__smstrahan__csharp.mp3.mp3
    * url: https://freesound.org/s/608990/
    * license: Creative Commons 0
  * 608989__smstrahan__dsharp.mp3.mp3
    * url: https://freesound.org/s/608989/
    * license: Creative Commons 0
  * 608988__smstrahan__fsharp.mp3.mp3
    * url: https://freesound.org/s/608988/
    * license: Creative Commons 0
  * 608987__smstrahan__g.mp3.mp3
    * url: https://freesound.org/s/608987/
    * license: Creative Commons 0
  * 608986__smstrahan__f.mp3.mp3
    * url: https://freesound.org/s/608986/
    * license: Creative Commons 0
  * 608985__smstrahan__d.mp3.mp3
    * url: https://freesound.org/s/608985/
    * license: Creative Commons 0
  * 608984__smstrahan__e.mp3.mp3
    * url: https://freesound.org/s/608984/
    * license: Creative Commons 0
  * 608983__smstrahan__a.mp3.mp3
    * url: https://freesound.org/s/608983/
    * license: Creative Commons 0
  * 608982__smstrahan__b.mp3.mp3
    * url: https://freesound.org/s/608982/
    * license: Creative Commons 0
  * 608981__smstrahan__c.mp3.mp3
    * url: https://freesound.org/s/608981/
    * license: Creative Commons 0


